Remarque : 
Chargement de la texture nécessite un server local.

Vous trouverez les explications de mon travail dans le fichier pdf.
CR_PBR_TianningMA.pdf